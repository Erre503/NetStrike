# main.py
from plugin_loaderTest import *

# Requisiti: la funzione 'esegui' deve essere presente
print("Quale file PY vuoi eseguire?")
nome_plugin = input()
req = "execute"
folder = "plugin"

# Carica i plugin validi
plugin = caricaPlugin(folder, req, nome_plugin)

if plugin != 0:
    plugin.execute()
elif plugin == 1:
    print("Il plugin" +nome_plugin+ "non rispetta i requisiti: " +req)
else:
    print("plugin non trovato")