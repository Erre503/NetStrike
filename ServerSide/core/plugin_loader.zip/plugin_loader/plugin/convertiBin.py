def execute():
    print("Numero massimo inseribile: 1073741823")
    n = int(input("Inserisci un numero: "))
    cifra_bin = []

    # Codifica il numero in binario
    for i in range(30):
        if n % 2 == 0:
            cifra_bin.append(0)
        else:
            cifra_bin.append(1)
        n = n // 2  # Operazione di divisione intera per ottenere il valore successivo

    # Mostra il numero binario a partire dall'elemento più significativo
    print("Questo numero viene codificato in Binario come : ", end="")
    guardia = False
    for i in range(29, -1, -1):
        if guardia | cifra_bin[i] != 0:
            guardia = True
            print(cifra_bin[i], end="")



