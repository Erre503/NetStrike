def esegui():
    print("Plugin 2 eseguito!")