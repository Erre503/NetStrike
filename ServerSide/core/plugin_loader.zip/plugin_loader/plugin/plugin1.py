def esegui():
    print("Plugin 1 eseguito!")



#funzione main globale che fa da tramite per far funzionare il plugin